window.firebaseConfig = {
  apiKey: "AIzaSyCI1QpQsG4ZXPOOD4yjKzO6prn5lLZx7uQ",
  authDomain: "xinghong-rpg.firebaseapp.com",
  projectId: "xinghong-rpg",
  storageBucket: "xinghong-rpg.firebasestorage.app",
  messagingSenderId: "740313786914",
  appId: "1:740313786914:web:783355049183af5261387b",
  measurementId: "G-1E4G580C4W"
};